window.commonurl="http://192.168.10.125:8080/rentHouse/";
window.commonurlimg="http://192.168.10.125:8080";

